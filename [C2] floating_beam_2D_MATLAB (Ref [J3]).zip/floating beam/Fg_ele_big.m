% A function related to Fg
function Fg_ele_big = Fg_ele_big(el_coord)

% Integration by Gaussian Legendre Quadrature
global p_dof omega_2 g rho_w;
span = abs(el_coord(end) - el_coord(1));
Fg_ele_big = zeros(2, p_dof);
Gauss_p = [0.97390653, 0.86506337, 0.67940957, 0.43339539, 0.14887434, ...
    -0.97390653, -0.86506337, -0.67940957, -0.43339539, -0.14887434];
weight = [0.06667134, 0.14945135, 0.21908636, 0.26926672, 0.29552422, ...
    0.06667134, 0.14945135, 0.21908636, 0.26926672, 0.29552422];

for i = 1 : 10
    s = Gauss_p(i);
    Hs = [1/2*(1 - s); 1/2*(1 + s)];

    Fg_ele_big = Fg_ele_big + Hs*Fg_sub((s + 1)/2*span + el_coord(1))*weight(i)*span/2*omega_2/(rho_w*g^2);
end