% A function that computes the M_ele
function M_ele = M_ele(el, span_xbar)

global EI eqns_w w_beam;

% nodal position
M_ele = zeros(2,1);
nodal_p = [ -1  1 ];

% nodal displacement
disp = zeros(4,1);
for i = 1 : 4
    eqns = eqns_w(el, i);
    disp(i,1) = w_beam(eqns);
end

for i = 1 : 2
    r = nodal_p(i);
    dHwdr_2 = [3/2*r, span_xbar/4*((r + 1) + (2*r - 2)), -3/2*r, span_xbar/4*((r - 1) + (2*r + 2))];
    M_ele(i,1) = abs((4*EI)/(span_xbar^2)*dHwdr_2*disp);
end
