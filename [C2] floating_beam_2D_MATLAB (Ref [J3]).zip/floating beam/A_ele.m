% A function that computes the A_ele
function A_ele = A_ele(span_xbar)

A_ele = zeros(4,2);
Gauss_p = [0, -sqrt(15)/5, sqrt(15)/5];
weight = [8/9, 5/9, 5/9];

for i = 1 : 3
    r = Gauss_p(i);
    Hw = [1/4*(1 - r)^2*(2 + r), span_xbar/8*(1 - r)^2*(1 + r), ...
         1/4*(1 + r)^2*(2 - r), -span_xbar/8*(1 + r)^2*(1 - r)];
    Hp = [1/2*(1 - r), 1/2*(1 + r)];

    A_ele = A_ele + Hw'*Hp*weight(i)*span_xbar/2;
end