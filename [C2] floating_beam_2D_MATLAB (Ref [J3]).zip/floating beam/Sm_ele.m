% A function that computes the Sm_ele
function Sm_ele = Sm_ele(span_xbar)

global rho_s H omega_2;
% global mu;
Sm_ele = zeros(4,4);
Gauss_p = [sqrt((3 - 2*sqrt(6/5))/7), -sqrt((3 - 2*sqrt(6/5))/7), ... 
    sqrt((3 + 2*sqrt(6/5))/7), -sqrt((3 + 2*sqrt(6/5))/7)];
weight = [(18 + sqrt(30))/36, (18 + sqrt(30))/36, (18 - sqrt(30))/36, (18 - sqrt(30))/36];

for i = 1 : 4
    r = Gauss_p(i);
    Hw = [1/4*(1 - r)^2*(2 + r), span_xbar/8*(1 - r)^2*(1 + r), ...
         1/4*(1 + r)^2*(2 - r), -span_xbar/8*(1 + r)^2*(1 - r)];

      Sm_ele = Sm_ele + Hw'*Hw*weight(i)*span_xbar/2*rho_s*H*omega_2;
end