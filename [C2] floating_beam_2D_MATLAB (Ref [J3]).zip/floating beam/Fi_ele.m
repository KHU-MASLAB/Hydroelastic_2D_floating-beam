% A function that computes the Fi_ele
function Fi_ele = Fi_ele(el_coord)

global k rho_w g amp;

% Integration by Gaussian Legendre Quadrature
Fi_ele = zeros(2,1);
span = abs(el_coord(end) - el_coord(1));
Gauss_p = [0.97390653, 0.86506337, 0.67940957, 0.43339539, 0.14887434, ...
    -0.97390653, -0.86506337, -0.67940957, -0.43339539, -0.14887434];
weight = [0.06667134, 0.14945135, 0.21908636, 0.26926672, 0.29552422, ... 
    0.06667134, 0.14945135, 0.21908636, 0.26926672, 0.29552422];

for i = 1 : 10
    r = Gauss_p(i);
    Hr = [1/2*(1 - r); 1/2*(1 + r)];
    
    Fi_ele = Fi_ele + Hr*exp(1i*k*((r + 1)/2*span + el_coord(1)))*weight(i)*span/2*amp;
end
