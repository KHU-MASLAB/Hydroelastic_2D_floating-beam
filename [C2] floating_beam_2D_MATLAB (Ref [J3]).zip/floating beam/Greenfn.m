% [2D Green function for finite depth]  
% A function that computes the Green function
function Greenfn = Greenfn(r, s)

global L g k h omega_2 sj;
Greenfn = (1i*L*k*exp(-1i*k*abs(s - r))) / (h/L*((L*k)^2 - (L/g*omega_2)^2) + L/g*omega_2);

for i = 1 : length(sj)
    Greenfn = Greenfn - (L*sj(i)*exp(-sj(i)*abs(s - r))) / (h/L*((L*sj(i))^2 + (L/g*omega_2)^2) - L/g*omega_2);
end



