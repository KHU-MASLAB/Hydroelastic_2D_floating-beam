% A function related to Fg
function Fg_sub = Fg_sub(s)

global nelem coord_node eqns_p p_dof;
Fg_sub = zeros(1, p_dof);
for i = 1 : nelem
    el_coord = coord_node(eqns_p(i,1) : eqns_p(i,2));
    Fg_el_sub = Fg_ele_sub(s,el_coord);
    Fg_sub(eqns_p(i,1)) = Fg_sub(eqns_p(i,1)) + Fg_el_sub(1);
    Fg_sub(eqns_p(i,2)) = Fg_sub(eqns_p(i,2)) + Fg_el_sub(2);
end
