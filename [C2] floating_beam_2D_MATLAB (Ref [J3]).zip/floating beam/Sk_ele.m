% A function that computes the Sk_ele
function Sk_ele = Sk_ele(span_xbar)

global EI B;
% global beta_4;
Sk_ele = zeros(4,4);

Gauss_p = [sqrt((3 - 2*sqrt(6/5))/7), -sqrt((3 - 2*sqrt(6/5))/7), ... 
    sqrt((3 + 2*sqrt(6/5))/7), -sqrt((3 + 2*sqrt(6/5))/7)];
weight = [(18 + sqrt(30))/36, (18 + sqrt(30))/36, (18 - sqrt(30))/36, (18 - sqrt(30))/36];

for i = 1 : 4
    r = Gauss_p(i);
    dHwdr_2 = [3/2*r, span_xbar/4*((r + 1) + (2*r - 2)), -3/2*r, span_xbar/4*((r - 1) + (2*r + 2))];
    
    Sk_ele = Sk_ele + dHwdr_2'*dHwdr_2*weight(i)*(2/span_xbar)^2*(2/span_xbar)^2*span_xbar/2*EI/B;
end
