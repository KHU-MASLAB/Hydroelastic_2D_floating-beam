% A function related to Fg
function Fg_ele_sub = Fg_ele_sub(s,el_coord)

% Integration by Gaussian Legendre Quadrature
Fg_ele_sub = zeros(1,2);
span = abs(el_coord(end) - el_coord(1));
Gauss_p = [0.97390653, 0.86506337, 0.67940957, 0.43339539, 0.14887434, ...
    -0.97390653, -0.86506337, -0.67940957, -0.43339539, -0.14887434];
weight = [0.06667134, 0.14945135, 0.21908636, 0.26926672, 0.29552422, ...
    0.06667134, 0.14945135, 0.21908636, 0.26926672, 0.29552422];

for i = 1 : 10
    r = Gauss_p(i);
    Hr = [1/2*(1 - r), 1/2*(1 + r)];
    
    Fg_ele_sub = Fg_ele_sub + Hr*Greenfn((r + 1)/2*span + el_coord(1), s)*weight(i)*span/2;
end