% A function that computes the Fm_ele
function Fm_ele = Fm_ele(span_xbar)

global rho_w g 
Fm_ele = zeros(2,2);
Gauss_p = [-1 1]/sqrt(3);

for i = 1 : 2
    r = Gauss_p(i);
    H = [1/2*(1 - r), 1/2*(1 + r)];
  
    Fm_ele = Fm_ele + H'*H*(span_xbar/2)/(rho_w*g) ;
end