% %-----------------------------------------------------------------------%
% %   Hydroelastic analysis of the Euler-Bernoulli beam (2D problem)      %
% %                                                                       %
% %   [ Method and Assumption ]                                           %
% %   - Euler-Bernoulli beam theory  - Hermitian beam element             %
% %   - Linear potential theory - 2 nodes for pressure                    %
% %   - 2D Green function for finite depth                                %
% %   - incident wave angle =  0 deg                                      %
% %   - very small draft effect                                           %
% %                                                                       %
% %   [Reference]                                                         %
% %   - Hydroelastic analysis of plates and some approximations,          % 
% %     RE Taylor,J ENG Math, 2007                                        %                                                              
% %   - Hydroelastic analysis of three dimensional floating structures,   %
% %     KT Kim, Master thesis, 2011                                       %
% %   - Kim, J.G., Cho, S.P., Kim, K.T., & Lee, P.S. (2014).              % 
% %     Hydroelastic design contour for the preliminary design of         %
% %     very large floating structures. Ocean Engineering, 78, 112-123.   %  
% %                                                                       %
% %   created by Jin-Gyun Kim, 2011                                       %  
% %   jingyun.kim@khu.ac.kr                                               %
% %   Modeling&Simulation lab                                             %
% %   Department of Mechanicl Engineering, Kyung Hee University           %
% %   https://sites.google.com/site/modelingnsimulation/                  %
% %-----------------------------------------------------------------------%

clc
clear

% Dimensionless properties (reference data)
% ref : Hydroelastic analysis of plates and some approximations, RE Taylor,J ENG Math, 2007
% beta_4 = 4.8025e-6;     % beta_4 = E*I / (rho_w*g*L^4);
% mu = 8.36e-4;           % mu = d / L;
% delta = 0.11;           % delta = h / L;
% k_b = 19.2823;         % k_b = k / (1/L);
% lk_b = 19.2823;          lk_b = k_b*tanh(k_b*delta);

% % Beam structure properties
% L = 10;                      % length
% H = 1;                       % height
% B = 1;                       % breadth
% E = 5.789e3;                 % Young's modulus
% I = 1/12 * B*H^3;            % moment of inertia of the cross section about neutral axis
% EI = E*I;                    % bending rigidity
% rho_s = 8.5690;              % density of structure

% % Fluid properties
% g = 9.8;                      % gravity acceleration
% rho_w = 1025;                 % density of water
% h = 1.1;                      % water depth
% lambda = 3.175712;            % wavelength
% k = 2*pi / lambda;            % wave number
% omega_2 = k*g*tanh(k*h);      % angular frequency square
% omega = (omega_2)^0.5;        % angular frequency
% amp = 0.001;                  % wave amplitude
% d = rho_s*H/rho_w;            % draft

% [step1] Input the properties --------------------------------------------
% properties
global L g rho_w k h amp omega_2 EI B H rho_s
% Beam structure properties
L = 500;                      % length
H = 1;                       % height
B = 50;                       % breadth
E = 30e8;                 % Young's modulus
I = 1/12 * B*H^3;            % moment of inertia of the cross section about neutral axis
EI = E*I;                    % bending rigidity
rho_s = 1025*9/10;              % density of structure

% Fluid properties
g = 9.8;                      % gravity acceleration
rho_w = 1025;                 % density of water
h = 5000;                      % water depth
lambda = 100;            % wavelength
k = 2*pi / lambda;            % wave number
omega_2 = k*g*tanh(k*h);      % angular frequency square
omega = (omega_2)^0.5;        % angular frequency
amp = 0.001;                  % wave amplitude
d = rho_s*H/rho_w;            % draft

% for legend of dimensionless parameters
delta = h/L;
k_b = k*L;
lk_b = k_b*tanh(k_b*delta);
beta_4 = E*I / (rho_w*g*L^4);

% [step2] Generate the input informations ---------------------------------
% element number, nodal coordinate, connectivity and equation number

% Spacial discretization
global nelem;
nelem = input('Input the number of elements = ');   % number of elements
nnode = nelem + 1;  % number of nodes

% Degree of freedom
global displ_dof p_dof total_dof;
displ_dof = 2*nnode;    % displacement degree of freedom per node (w, theta)
p_dof = nnode;  % pressure degree of freedom per node
total_dof = displ_dof + p_dof;  % total degree of freedom

% The nodal coordinate
global coord_node;
span_xbar = L / nelem;          % element size
coord_node = zeros(1,nnode);    % the nodal coordinate
for i = 1 : nnode - 1
    coord_node(i+1) = i*span_xbar;
end

% equation number of pressure (fluid)
global eqns_p;
eqns_p = zeros(nelem,2);
startn = 1;
for i = 1 : nelem
    eqns_p(i,1) = startn;
    eqns_p(i,2) = startn + 1;
    startn = startn + 1;
end

% equation number of displacement (structure)
global eqns_w;
eqns_w = zeros(nelem,4);
startn = 1;
for i = 1 : nelem
    eqns_w(i,1) = startn;
    eqns_w(i,2) = startn + 1;
    eqns_w(i,3) = startn + 2;
    eqns_w(i,4) = startn + 3;
    startn = eqns_w(i,3);
end

% [step3] solution of dispersion relation (sj) ------------------
% using Newton Raphson method
global sj;
sj = zeros(50,1);
err = 0.01; % error for sj
for i = 1 : length(sj)
    % How to select the starting point without overshooting the NR method?
    x = linspace(0,pi/2,300);
%     y = tan(x) - omega_2*h/g ./ (j*Fi - x);
%     y = sin(x).*(j*Fi - x) - omega_2*h/g*cos(x);
%     plot(x,y);
    dydx = cos(x).*(i*pi - x) + (omega_2*h/g - 1).*sin(x); % dy/dx
    [val loc] = max(dydx);
    theta_j1 = x(loc); % To avoid overshoot in Newton-Raphson method, we select the x when the dy/dx is maximum.
    dum_err = 100;
    
    % x(i+1) = x(i) - y(x(i)) / y'(x(i))
    while(dum_err >= err) 
        theta_j2 = theta_j1 - (sin(theta_j1)*(i*pi - theta_j1) - omega_2*h/g*cos(theta_j1))/(cos(theta_j1)*(i*pi - theta_j1) + (omega_2*h/g - 1)*sin(theta_j1));
        dum_err = abs(theta_j2 - theta_j1) / abs(theta_j1);
        theta_j1 = theta_j2;
    end
    
    sj(i) = (i*pi - theta_j2) / h;
end

% [step4] Assemble the matrix : Fm, Fg, Fc, Fi, Sk, Sm, Sc ----------------
% Assembling
% [  Sm - Sk ,       Sc ][ W ] = [ 0  ]
% [  Fc,        Fm - Fg ][ P ]   [ Fi ]

% Sk = structure stiffness
% Sm = structure mass
% Fm = fluid stiffness
% Fg = fluid mass
% Sc, Fc = coupling matrix 
% Fi = incidnet pressure

% Construct "Sk & Sm"
Sk = zeros(displ_dof, displ_dof);
Sm = zeros(displ_dof, displ_dof);
for el = 1 : nelem
    Sk_elem = Sk_ele(span_xbar);
    Sm_elem = Sm_ele(span_xbar);
    for i = 1 : 4
        for j = 1 : 4
            Sk(eqns_w(el,i),eqns_w(el,j)) = Sk(eqns_w(el,i),eqns_w(el,j)) + Sk_elem(i,j);
            Sm(eqns_w(el,i),eqns_w(el,j)) = Sm(eqns_w(el,i),eqns_w(el,j)) + Sm_elem(i,j);
        end
    end
end

% Construct "Fm"
Fm = zeros(p_dof, p_dof);
for el = 1 : nelem
    Fm_elem = Fm_ele(span_xbar);
    for i = 1 : 2
        for j = 1 : 2
            Fm(eqns_p(el,i),eqns_p(el,j)) = Fm(eqns_p(el,i),eqns_p(el,j)) + Fm_elem(i,j);
        end
    end
end

% Construct "Sc, Fc"
A = zeros(displ_dof, p_dof);
for el = 1 : nelem
    A_elem = A_ele(span_xbar);
    for i = 1 : 4
        for j = 1 : 2
            A(eqns_w(el,i),eqns_p(el,j)) = A(eqns_w(el,i),eqns_p(el,j)) + A_elem(i,j);
        end
    end
end
Sc = A;     % coupling matrix of structure
Fc = A';    % coupling matrix of fluid

% Construct "Fg"
Fg = zeros(p_dof, p_dof);
for el = 1 : nelem
    el_coord = coord_node(eqns_p(el, 1) : eqns_p(el,2));
    Fg_el_big = Fg_ele_big(el_coord);
    for i = 1 : 2
        Fg(eqns_p(el,i),:) = Fg(eqns_p(el,i),:) + Fg_el_big(i,:);
    end
end

% Assemble the total Fi vector
Fi = zeros(p_dof, 1);
for el = 1 : nelem
    el_coord = coord_node(eqns_p(el,1) : eqns_p(el,2));
    Fi_el = Fi_ele(el_coord);
    for i = 1 : 2
        Fi(eqns_p(el,i)) = Fi(eqns_p(el,i)) + Fi_el(i);
    end
end

% [step5] Response calculation --------------------------------------------
% Compute the diffraction pressure
Pdum = Fm - Fg;
Pd = (Pdum^-1)*Fi;      % diffraction pressure

% Compute the deflection of a beam
global w_beam;
Hdum = (Pdum^-1)*Fc;
Mdum = -Sm + Sc*Hdum + Sk;
w_beam = (Mdum^-1)*Sc*Pd;               % total displacement vector (w, theta)
w_beam_w = zeros(length(w_beam)/2, 1);   % selecting the heave motion(w)
for i = 1 : length(w_beam)/2
    w_beam_w(i) = w_beam(2*i - 1);
end

% Compute the total pressure
Pt = Pd - (Pdum^-1)*Fc*w_beam;

% Compute the hydrostatic pressure
Ps = -rho_w*g*w_beam_w;

% Compute the radiation pressure
Pr = Pt - Pd - Ps;

% Moment calculation
Moment = zeros(p_dof, 1);
for el = 1 : nelem
    el_coord = coord_node(eqns_p(el,1) : eqns_p(el,2));
    M_el = M_ele(el, span_xbar);
    for i = 1 : 2
        if Moment(eqns_p(el,i)) == 0
            Moment(eqns_p(el,i)) = Moment(eqns_p(el,i)) + M_el(i);
        else
            Moment(eqns_p(el,i)) = 1/2*(Moment(eqns_p(el,i)) + M_el(i));
        end
    end
end

% [step6] Print out the responses -----------------------------------------
% dimensionless quantities
dim_w = w_beam_w/amp;                                               % displacement (abs)
dim_Pd = Pd/(rho_w*g*amp);                                          % diffraction pressure
dim_Pt = dim_Pd - (Pdum^-1)*A.'*w_beam/(rho_w*g*amp);               % total pressure
dim_Ps = Ps/(rho_w*g*amp);                                          % hydroelastic pressure
dim_Pr = Pr/(rho_w*g*amp);                                          % radiational pressure

% Plotting the dimensionless pressures (Pd, Pt, Ps, Pr)
 x1 = linspace(0, L, p_dof);
scrsz = get(0,'ScreenSize');
% figure('Position',[scrsz(3)/4 scrsz(4)/8 scrsz(3)/1.5 scrsz(4)/1.3])
% subplot(4,1,1)
% plot(x1/L, real(dim_Pt), 'b', x1/L, imag(dim_Pt), '--r');
% ylabel('total P');
% subplot(4,1,2)
% plot(x1/L, real(dim_Pd), 'b', x1/L, imag(dim_Pd), '--r');
% ylabel('diffraction P');
% subplot(4,1,3)
% plot(x1/L, real(dim_Ps), 'b', x1/L, -imag(dim_Ps), '--r');
% ylabel('hydrostatic P');
% subplot(4,1,4)
% plot(x1/L, real(dim_Pr), 'b', x1/L, imag(dim_Pr), '--r');
% ylabel('radiation P');

% Plotting the dimensionless deflection (w)
figure(2)
plot(x1/L, abs(dim_w), 'k.-', x1/L, abs(real(dim_w)), 'b', x1/L, abs(imag(dim_w)), '--r');
xlabel('x');
ylabel('deflection(u/a)');
legend('absolute value', 'real(u/a)', 'imag(u/a)');
title(['delta = ', num2str(delta), ', K = ', num2str(lk_b), ', beta^4 = ', num2str(beta_4)]);
axis([x1(1)/L  x1(end)/L  -0.3*min(abs(dim_w)) 1.5*max(abs(dim_w))]);

% Plotting the Moment (M)
figure(3)
plot(x1/L, Moment/amp, 'k.-');
xlabel('x');
ylabel('Moment(Nm/m)');
axis([x1(1)/L  x1(end)/L  -0.3*min(Moment/amp) 1.5*max(Moment/amp)]);

%  % animation of the dimensionless deflection (w)
%  lt = 2*pi/omega;
%  n = 200;
%  t = linspace(0,2*lt,n);
%  figure(4)
%  for i = 1 : n
%      wm = real(w_beam_w*(exp(1i*omega*t(i)))/amp);
%      plot(x1/L, abs(wm), 'b');
%      xlabel('x');
%      ylabel('deflection (w/a)');
%      axis([x1(1)/L x1(end)/L -0.3*min(abs(dim_w)) 1.5*max(abs(dim_w))]);
%      F(i) = getframe;
%  end

